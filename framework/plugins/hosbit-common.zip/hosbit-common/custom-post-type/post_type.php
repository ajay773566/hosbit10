<?php

// register post type Service

add_action( 'init', 'register_hosbit_Service' );

function register_hosbit_Service() {

    

    $labels = array( 

        'name' => __( 'Service', 'hosbit' ),

        'singular_name' => __( 'Service', 'hosbit' ),

        'add_new' => __( 'Add New Service', 'hosbit' ),

        'add_new_item' => __( 'Add New Service', 'hosbit' ),

        'edit_item' => __( 'Edit Service', 'hosbit' ),

        'new_item' => __( 'New Service', 'hosbit' ),

        'view_item' => __( 'View Service', 'hosbit' ),

        'search_items' => __( 'Search Service', 'hosbit' ),

        'not_found' => __( 'No Service found', 'hosbit' ),

        'not_found_in_trash' => __( 'No Service found in Trash', 'hosbit' ),

        'parent_item_colon' => __( 'Parent Service:', 'hosbit' ),

        'menu_name' => __( 'Service', 'hosbit' ),

    );



    $args = array( 

        'labels' => $labels,

        'hierarchical' => true,

        'description' => 'List Service',

        'supports' => array( 'title', 'editor', 'thumbnail', 'comments'),

        'taxonomies' => array( 'Service', 'type' ),

        'public' => true,

        'show_ui' => true,

        'show_in_menu' => true,

        'menu_position' => 5,

        'menu_icon' => 'dashicons-portfolio', 

        'show_in_nav_menus' => true,

        'publicly_queryable' => true,

        'exclude_from_search' => false,

        'has_archive' => true,

        'query_var' => true,

        'can_export' => true,

        'rewrite' => true,

        'capability_type' => 'post'

    );



    register_post_type( 'Service', $args );

}

add_action( 'init', 'create_Type_hierarchical_taxonomy', 0 );



//create a custom taxonomy name it Skillss for your posts



function create_Type_hierarchical_taxonomy() {



// Add new taxonomy, make it hierarchical like Skills

//first do the translations part for GUI



  $labels = array(

    'name' => __( 'Type', 'hosbit' ),

    'singular_name' => __( 'Type', 'hosbit' ),

    'search_items' =>  __( 'Search Type','hosbit' ),

    'all_items' => __( 'All Type','hosbit' ),

    'parent_item' => __( 'Parent Type','hosbit' ),

    'parent_item_colon' => __( 'Parent Type:','hosbit' ),

    'edit_item' => __( 'Edit Type','hosbit' ), 

    'update_item' => __( 'Update Type','hosbit' ),

    'add_new_item' => __( 'Add New Type','hosbit' ),

    'new_item_name' => __( 'New Type Name','hosbit' ),

    'menu_name' => __( 'Type','hosbit' ),

  );     



// Now register the taxonomy



  register_taxonomy('type',array('Service'), array(

    'hierarchical' => true,

    'labels' => $labels,

    'show_ui' => true,

    'show_admin_column' => true,

    'query_var' => true,

    'rewrite' => array( 'slug' => 'type' ),

  ));



}



// register post type2 Project

add_action( 'init', 'register_hosbit_Project' );

function register_hosbit_Project() {

    

    $labels = array( 

        'name' => __( 'Project', 'hosbit' ),

        'singular_name' => __( 'Project', 'hosbit' ),

        'add_new' => __( 'Add New Project', 'hosbit' ),

        'add_new_item' => __( 'Add New Project', 'hosbit' ),

        'edit_item' => __( 'Edit Project', 'hosbit' ),

        'new_item' => __( 'New Project', 'hosbit' ),

        'view_item' => __( 'View Project', 'hosbit' ),

        'search_items' => __( 'Search Project', 'hosbit' ),

        'not_found' => __( 'No Project found', 'hosbit' ),

        'not_found_in_trash' => __( 'No Project found in Trash', 'hosbit' ),

        'parent_item_colon' => __( 'Parent Project:', 'hosbit' ),

        'menu_name' => __( 'Project', 'hosbit' ),

    );



    $args = array( 

        'labels' => $labels,

        'hierarchical' => true,

        'description' => 'List Project',

        'supports' => array( 'title', 'editor', 'thumbnail', 'comments'),

        'taxonomies' => array( 'Project', 'type2', 'category1' ),

        'public' => true,

        'show_ui' => true,

        'show_in_menu' => true,

        'menu_position' => 5,

        'menu_icon' => 'dashicons-portfolio', 

        'show_in_nav_menus' => true,

        'publicly_queryable' => true,

        'exclude_from_search' => false,

        'has_archive' => true,

        'query_var' => true,

        'can_export' => true,

        'rewrite' => true,

        'capability_type' => 'post'

    );



    register_post_type( 'Project', $args );

}

add_action( 'init', 'create_type2_hierarchical_taxonomy', 0 );

add_action( 'init', 'create_Category1_hierarchical_taxonomy', 0 );



//create a custom taxonomy name it Skillss for your posts



function create_type2_hierarchical_taxonomy() {



// Add new taxonomy, make it hierarchical like Skills

//first do the translations part for GUI



  $labels = array(

    'name' => __( 'Type', 'hosbit' ),

    'singular_name' => __( 'Type', 'hosbit' ),

    'search_items' =>  __( 'Search Type','hosbit' ),

    'all_items' => __( 'All Type','hosbit' ),

    'parent_item' => __( 'Parent Type','hosbit' ),

    'parent_item_colon' => __( 'Parent Type:','hosbit' ),

    'edit_item' => __( 'Edit Type','hosbit' ), 

    'update_item' => __( 'Update Type','hosbit' ),

    'add_new_item' => __( 'Add New Type','hosbit' ),

    'new_item_name' => __( 'New Type Name','hosbit' ),

    'menu_name' => __( 'Type','hosbit' ),

  );     



// Now register the taxonomy



  register_taxonomy('type2',array('Project'), array(

    'hierarchical' => true,

    'labels' => $labels,

    'show_ui' => true,

    'show_admin_column' => true,

    'query_var' => true,

    'rewrite' => array( 'slug' => 'type2' ),

  ));



}



function create_Category1_hierarchical_taxonomy() {



// Add new taxonomy, make it hierarchical like Skills

//first do the translations part for GUI



  $labels = array(

    'name' => __( 'Category', 'hosbit' ),

    'singular_name' => __( 'Category', 'hosbit' ),

    'search_items' =>  __( 'Search Category','hosbit' ),

    'all_items' => __( 'All Category','hosbit' ),

    'parent_item' => __( 'Parent Category','hosbit' ),

    'parent_item_colon' => __( 'Parent Category:','hosbit' ),

    'edit_item' => __( 'Edit Category','hosbit' ), 

    'update_item' => __( 'Update Category','hosbit' ),

    'add_new_item' => __( 'Add New Category','hosbit' ),

    'new_item_name' => __( 'New Category Name','hosbit' ),

    'menu_name' => __( 'Category','hosbit' ),

  );     



// Now register the taxonomy



  register_taxonomy('category1',array('Project'), array(

    'hierarchical' => true,

    'labels' => $labels,

    'show_ui' => true,

    'show_admin_column' => true,

    'query_var' => true,

    'rewrite' => array( 'slug' => 'category1' ),

  ));



}



?>