<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsPricingVersionOne extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-pricing-one';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Pricing Version One', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Pricing widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-price-table';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Pricing widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'bdevs-elementor' ];
	}

	public function get_keywords() {
		return [ 'pricing' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
	    $position_options = [
	        ''              => esc_html__('Default', 'bdevs-elementor'),
	        'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
	        'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
	        'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
	        'center'        => esc_html__('Center', 'bdevs-elementor') ,
	        'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
	        'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
	        'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
	        'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') ,
	        'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
	    ];

	    return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_heading',
			[
				'label' => esc_html__( 'Pricing Version One', 'bdevs-elementor' ),
			]	
		);

		$this->add_control(
			'chose_style',
			[
				'label'     => esc_html__( 'Chose Style', 'bdevs-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'pricing_style_1'  => esc_html__( 'Background Normal', 'bdevs-elementor' ),
					'pricing_style_2' => esc_html__( 'Background Full Bottom', 'bdevs-elementor' ),
				],
				'default'   => 'pricing_style_1',
			]
		);

		$this->add_control(
			'background_bg',
			[
				'label'   => esc_html__( 'Background Image', 'bdevs-elementor' ),
				'type'    => Controls_Manager::MEDIA,
				'dynamic' => [ 'active' => true ],
				'description' => esc_html__( 'Add image from here', 'bdevs-elementor' ),
			]
		);

		$this->add_control(
			'subheading',
			[
				'label'       => __( 'Subheading', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your subheading', 'bdevs-elementor' ),
				'default'     => __( 'This is subheading', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'heading',
			[
				'label'       => __( 'Heading', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your heading', 'bdevs-elementor' ),
				'default'     => __( 'This is heading', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_content_pricing',
			[
				'label' => esc_html__( 'Pricing Table', 'bdevs-elementor' ),
			]
		);

		$this->add_control(
			'title',
			[
				'label'       => __( 'Title', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your title', 'bdevs-elementor' ),
				'default'     => __( 'This is title', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'period1',
			[
				'label'       => __( 'Period 1', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Period 1', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'period2',
			[
				'label'       => __( 'Period 2', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'Period 2', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'tabs',
			[
				'label' => esc_html__( 'Pricing Items', 'bdevs-elementor' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => [	
					[
						'name'        => 'title_pricing',
						'label'       => esc_html__( 'Title', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Title' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'subtitle_pricing',
						'label'       => esc_html__( 'Subtitle', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Subtitle' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'price1',
						'label'       => esc_html__( 'Price 1', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Price 1' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'price2',
						'label'       => esc_html__( 'Price 2', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Price 2' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'button',
						'label'       => esc_html__( 'Text Button', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Button' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'link_button',
						'label'       => esc_html__( 'Link Button', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( '#' , 'bdevs-elementor' ),
						'label_block' => true,
					],

				],
			]
		);

		$this->add_control(
			'tabs2',
			[
				'label' => esc_html__( 'Pricing Info', 'bdevs-elementor' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => [	
					[
						'name'        => 'title_2',
						'label'       => esc_html__( 'Title', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Title' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'content_2',
						'label'       => esc_html__( 'Content', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXTAREA,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Content' , 'bdevs-elementor' ),
						'label_block' => true,
					],

				],
			]
		);

		$this->end_controls_section();


		/** 
		*	Layout section 
		**/
		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);		

		$this->add_control(
			'show_subheading',
			[
				'label'   => esc_html__( 'Show Subheading', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);	

		$this->add_control(
			'show_heading',
			[
				'label'   => esc_html__( 'Show Heading', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);	

		$this->end_controls_section();

	}

	public function render() {
		$settings  = $this->get_settings_for_display();
		$bg_src = wp_get_attachment_image_src( $settings['background_bg']['id'], 'full' );
		$bg_url = $bg_src ? $bg_src[0] : '';
		$chose_style = $settings['chose_style'];
		extract($settings);?>
		<?php if( $chose_style == 'pricing_style_1' ): ?>
		<section class="package-pricing-area package-pricing-bg" data-background="<?php print esc_url( $bg_url ); ?>">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xl-6 col-lg-8">
                        <div class="section-title text-center mb-70">
                            <?php if ( $settings['show_subheading'] ) : ?>
                            <span class="sub-title"><?php print wp_kses_post($settings['subheading']); ?></span>
                        	<?php endif; ?>
                            <?php if ( $settings['show_heading'] ) : ?>
                            <h2 class="title"><?php print wp_kses_post($settings['heading']); ?></h2>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="package-pricing-box">
                            <table class="table table-hover table-borderless">
                                <thead>
                                    <tr>
                                        <th scope="col" class="pack-pricing-tab">
                                            <div class="pack-pricing-head">
                                                <div class="icon"><i class="flaticon-sparkler"></i></div>
                                                <div class="pak-price-box-title"><?php print wp_kses_post($settings['title']); ?></div>
                                                <div class="pricing-tab">
                                                    <span class="tab-btn monthly_tab_title"><?php print wp_kses_post($settings['period1']); ?></span>
                                                    <span class="pricing-tab-switcher"></span>
                                                    <span class="tab-btn annual_tab_title"><?php print wp_kses_post($settings['period2']); ?></span>
                                                </div>
                                            </div>
                                        </th>
                                        <?php
						                    foreach ( $settings['tabs'] as $item ) : 
										?>
                                        <th scope="col" class="pack-price-info pricing-amount">
                                            <span class="pack-sub-title"><?php print wp_kses_post($item['title_pricing']); ?></span>
                                            <span class="pack-price-offer"><?php print wp_kses_post($item['subtitle_pricing']); ?></span>
                                            <div class="price annual_price"><?php print wp_kses_post($item['price2']); ?></div>
                                            <div class="price monthly_price"><?php print wp_kses_post($item['price1']); ?></div>
                                            <a href="<?php print wp_kses_post($item['link_button']); ?>" class="btn pack-price-btn"><?php print wp_kses_post($item['button']); ?></a>
                                        </th>
                                    	<?php endforeach; ?>
                                    </tr>
                                </thead>
                                <tbody>
                                	<?php
					                    foreach ( $settings['tabs2'] as $item ) : 
									?>
                                    <tr>
                                        <th scope="row"><?php print wp_kses_post($item['title_2']); ?></th>
                                        <?php print wp_kses_post($item['content_2']); ?>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <?php elseif( $chose_style == 'pricing_style_2' ): ?>
        <section class="package-pricing-area package-pricing-bg package-pricing-2" data-background="<?php print esc_url( $bg_url ); ?>">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xl-6 col-lg-8">
                        <div class="section-title text-center mb-70">
                            <?php if ( $settings['show_subheading'] ) : ?>
                            <span class="sub-title"><?php print wp_kses_post($settings['subheading']); ?></span>
                        	<?php endif; ?>
                            <?php if ( $settings['show_heading'] ) : ?>
                            <h2 class="title"><?php print wp_kses_post($settings['heading']); ?></h2>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="package-pricing-box">
                            <table class="table table-hover table-borderless">
                                <thead>
                                    <tr>
                                        <th scope="col" class="pack-pricing-tab">
                                            <div class="pack-pricing-head">
                                                <div class="icon"><i class="flaticon-sparkler"></i></div>
                                                <div class="pak-price-box-title"><?php print wp_kses_post($settings['title']); ?></div>
                                                <div class="pricing-tab">
                                                    <span class="tab-btn monthly_tab_title"><?php print wp_kses_post($settings['period1']); ?></span>
                                                    <span class="pricing-tab-switcher"></span>
                                                    <span class="tab-btn annual_tab_title"><?php print wp_kses_post($settings['period2']); ?></span>
                                                </div>
                                            </div>
                                        </th>
                                        <?php
						                    foreach ( $settings['tabs'] as $item ) : 
										?>
                                        <th scope="col" class="pack-price-info pricing-amount">
                                            <span class="pack-sub-title"><?php print wp_kses_post($item['title_pricing']); ?></span>
                                            <span class="pack-price-offer"><?php print wp_kses_post($item['subtitle_pricing']); ?></span>
                                            <div class="price annual_price"><?php print wp_kses_post($item['price2']); ?></div>
                                            <div class="price monthly_price"><?php print wp_kses_post($item['price1']); ?></div>
                                            <a href="<?php print wp_kses_post($item['link_button']); ?>" class="btn pack-price-btn"><?php print wp_kses_post($item['button']); ?></a>
                                        </th>
                                    	<?php endforeach; ?>
                                    </tr>
                                </thead>
                                <tbody>
                                	<?php
					                    foreach ( $settings['tabs2'] as $item ) : 
									?>
                                    <tr>
                                        <th scope="row"><?php print wp_kses_post($item['title_2']); ?></th>
                                        <?php print wp_kses_post($item['content_2']); ?>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <?php endif; ?>
	<?php
	}

}