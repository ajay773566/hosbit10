<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class BdevsPricingVersionFour extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'bdevs-pricing-four';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Pricing Version Four', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Pricing widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-price-table';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Pricing widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'bdevs-elementor' ];
	}

	public function get_keywords() {
		return [ 'pricing' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
	    $position_options = [
	        ''              => esc_html__('Default', 'bdevs-elementor'),
	        'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
	        'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
	        'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
	        'center'        => esc_html__('Center', 'bdevs-elementor') ,
	        'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
	        'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
	        'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
	        'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') ,
	        'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
	    ];

	    return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_content_heading',
			[
				'label' => esc_html__( 'Pricing Version Four', 'bdevs-elementor' ),
			]	
		);

		$this->add_control(
			'tab_title_1',
			[
				'label'       => __( 'Tab Title 1', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your title', 'bdevs-elementor' ),
				'default'     => __( 'Title 1', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'tab_title_2',
			[
				'label'       => __( 'Tab Title 2', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your title', 'bdevs-elementor' ),
				'default'     => __( 'Title 2', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'tab_title_3',
			[
				'label'       => __( 'Tab Title 3', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your title', 'bdevs-elementor' ),
				'default'     => __( 'Title 3', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_content_pricing_1',
			[
				'label' => esc_html__( 'Pricing Tab 1', 'bdevs-elementor' ),
			]
		);

		$this->add_control(
			'subheading',
			[
				'label'       => __( 'Subheading', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your subheading', 'bdevs-elementor' ),
				'default'     => __( 'This is subheading', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'heading',
			[
				'label'       => __( 'Heading', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your heading', 'bdevs-elementor' ),
				'default'     => __( 'This is heading', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'tabs',
			[
				'label' => esc_html__( 'Pricing Items', 'bdevs-elementor' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => [	
					[
						'name'        => 'icon',
						'label'       => esc_html__( 'Icon', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Icon' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'title_pricing',
						'label'       => esc_html__( 'Title', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Title' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'subtitle_pricing',
						'label'       => esc_html__( 'Subtitle', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Subtitle' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'price',
						'label'       => esc_html__( 'Price', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Price' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'period',
						'label'       => esc_html__( 'Period', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( '/mo' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'content',
						'label'       => esc_html__( 'Content', 'bdevs-elementor' ),
						'type'        => Controls_Manager::WYSIWYG,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Content' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'button',
						'label'       => esc_html__( 'Text Button', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Button' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'link_button',
						'label'       => esc_html__( 'Link Button', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( '#' , 'bdevs-elementor' ),
						'label_block' => true,
					],

				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_content_pricing_2',
			[
				'label' => esc_html__( 'Pricing Tab 2', 'bdevs-elementor' ),
			]
		);

		$this->add_control(
			'subheading_2',
			[
				'label'       => __( 'Subheading', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your subheading', 'bdevs-elementor' ),
				'default'     => __( 'This is subheading', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'heading_2',
			[
				'label'       => __( 'Heading', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your heading', 'bdevs-elementor' ),
				'default'     => __( 'This is heading', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'tabs2',
			[
				'label' => esc_html__( 'Pricing Items', 'bdevs-elementor' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => [	
					[
						'name'        => 'icon_2',
						'label'       => esc_html__( 'Icon', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Icon' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'title_pricing_2',
						'label'       => esc_html__( 'Title', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Title' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'subtitle_pricing_2',
						'label'       => esc_html__( 'Subtitle', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Subtitle' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'price_2',
						'label'       => esc_html__( 'Price', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Price' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'period_2',
						'label'       => esc_html__( 'Period', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( '/mo' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'content_2',
						'label'       => esc_html__( 'Content', 'bdevs-elementor' ),
						'type'        => Controls_Manager::WYSIWYG,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Content' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'button_2',
						'label'       => esc_html__( 'Text Button', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Button' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'link_button_2',
						'label'       => esc_html__( 'Link Button', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( '#' , 'bdevs-elementor' ),
						'label_block' => true,
					],

				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'section_content_pricing_3',
			[
				'label' => esc_html__( 'Pricing Tab 3', 'bdevs-elementor' ),
			]
		);

		$this->add_control(
			'subheading_3',
			[
				'label'       => __( 'Subheading', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your subheading', 'bdevs-elementor' ),
				'default'     => __( 'This is subheading', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'heading_3',
			[
				'label'       => __( 'Heading', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your heading', 'bdevs-elementor' ),
				'default'     => __( 'This is heading', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'tabs3',
			[
				'label' => esc_html__( 'Pricing Items', 'bdevs-elementor' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => [	
					[
						'name'        => 'icon_3',
						'label'       => esc_html__( 'Icon', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Icon' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'title_pricing_3',
						'label'       => esc_html__( 'Title', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Title' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'subtitle_pricing_3',
						'label'       => esc_html__( 'Subtitle', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Subtitle' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'price_3',
						'label'       => esc_html__( 'Price', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Price' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'period_3',
						'label'       => esc_html__( 'Period', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( '/mo' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'content_3',
						'label'       => esc_html__( 'Content', 'bdevs-elementor' ),
						'type'        => Controls_Manager::WYSIWYG,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Content' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'button_3',
						'label'       => esc_html__( 'Text Button', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Button' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'link_button_3',
						'label'       => esc_html__( 'Link Button', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( '#' , 'bdevs-elementor' ),
						'label_block' => true,
					],

				],
			]
		);

		$this->end_controls_section();


		/** 
		*	Layout section 
		**/
		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);		

		$this->add_control(
			'show_subheading',
			[
				'label'   => esc_html__( 'Show Subheading', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);	

		$this->add_control(
			'show_heading',
			[
				'label'   => esc_html__( 'Show Heading', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);	

		$this->end_controls_section();

	}

	public function render() {
		$settings  = $this->get_settings_for_display();		extract($settings);?>
		<!-- pricing-area -->
            <section class="pricing-area gray-bg position-relative pt-100 pb-70">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <div class="pricing-box-tabs">
                                <ul class="nav nav-tabs" id="myTab" role="tablist">
                                    <li class="nav-item" role="presentation">
                                        <a class="nav-link active" id="web-hosting-tab" data-toggle="tab" href="#web-hosting" role="tab" aria-controls="web-hosting"
                                            aria-selected="true"><?php print wp_kses_post($settings['tab_title_1']); ?></a>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <a class="nav-link" id="website-builder-tab" data-toggle="tab" href="#website-builder" role="tab" aria-controls="website-builder"
                                            aria-selected="false"><?php print wp_kses_post($settings['tab_title_2']); ?></a>
                                    </li>
                                    <li class="nav-item" role="presentation">
                                        <a class="nav-link" id="online-store-tab" data-toggle="tab" href="#online-store" role="tab" aria-controls="online-store"
                                            aria-selected="false"><?php print wp_kses_post($settings['tab_title_3']); ?></a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade show active" id="web-hosting" role="tabpanel" aria-labelledby="web-hosting-tab">
                            <div class="row justify-content-center">
                                <div class="col-xl-7 col-lg-9">
                                    <div class="section-title text-center mb-70">
                                        <?php if ( $settings['show_subheading'] ) : ?>
			                            <span class="sub-title"><?php print wp_kses_post($settings['subheading']); ?></span>
			                        	<?php endif; ?>
			                            <?php if ( $settings['show_heading'] ) : ?>
			                            <h2 class="title"><?php print wp_kses_post($settings['heading']); ?></h2>
			                            <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row pricing-box-wrap justify-content-center">
                            	<?php
				                    foreach ( $settings['tabs'] as $item ) : 
								?>
			                    <div class="col-lg-4 col-md-6 col-sm-9">
			                        <div class="pricing-box mb-30">
			                            <div class="pricing-head">
			                                <h6><?php print wp_kses_post($item['title_pricing']); ?></h6>
			                                <div class="pricing-icon services-icon">
			                                    <i class="<?php print wp_kses_post($item['icon']); ?>"></i>
			                                </div>
			                            </div>
			                            <div class="pricing-list mb-30">
			                                <h5><?php print wp_kses_post($item['subtitle_pricing']); ?></h5>
			                                <ul>
			                                    <?php print wp_kses_post($item['content']); ?>
			                                </ul>
			                            </div>
			                            <div class="price mb-20">
			                                <h2><?php print wp_kses_post($item['price']); ?><span><?php print wp_kses_post($item['period']); ?></span></h2>
			                            </div>
			                            <div class="pricing-btn">
			                                <a href="<?php print wp_kses_post($item['link_button']); ?>" class="btn"><?php print wp_kses_post($item['button']); ?></a>
			                            </div>
			                        </div>
			                    </div>
			                	<?php endforeach; ?>

                            </div>
                        </div>
                        <div class="tab-pane fade" id="website-builder" role="tabpanel" aria-labelledby="website-builder-tab">
                            <div class="row justify-content-center">
                                <div class="col-xl-7 col-lg-9">
                                    <div class="section-title text-center mb-70">
                                        <?php if ( $settings['show_subheading'] ) : ?>
			                            <span class="sub-title"><?php print wp_kses_post($settings['subheading_2']); ?></span>
			                        	<?php endif; ?>
			                            <?php if ( $settings['show_heading'] ) : ?>
			                            <h2 class="title"><?php print wp_kses_post($settings['heading_2']); ?></h2>
			                            <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row pricing-box-wrap justify-content-center">
                                <?php
				                    foreach ( $settings['tabs2'] as $item ) : 
								?>
			                    <div class="col-lg-4 col-md-6 col-sm-9">
			                        <div class="pricing-box mb-30">
			                            <div class="pricing-head">
			                                <h6><?php print wp_kses_post($item['title_pricing_2']); ?></h6>
			                                <div class="pricing-icon services-icon">
			                                    <i class="<?php print wp_kses_post($item['icon_2']); ?>"></i>
			                                </div>
			                            </div>
			                            <div class="pricing-list mb-30">
			                                <h5><?php print wp_kses_post($item['subtitle_pricing_2']); ?></h5>
			                                <ul>
			                                    <?php print wp_kses_post($item['content_2']); ?>
			                                </ul>
			                            </div>
			                            <div class="price mb-20">
			                                <h2><?php print wp_kses_post($item['price_2']); ?><span><?php print wp_kses_post($item['period_2']); ?></span></h2>
			                            </div>
			                            <div class="pricing-btn">
			                                <a href="<?php print wp_kses_post($item['link_button_2']); ?>" class="btn"><?php print wp_kses_post($item['button_2']); ?></a>
			                            </div>
			                        </div>
			                    </div>
			                	<?php endforeach; ?>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="online-store" role="tabpanel" aria-labelledby="online-store-tab">
                            <div class="row justify-content-center">
                                <div class="col-xl-7 col-lg-9">
                                    <div class="section-title text-center mb-70">
                                        <?php if ( $settings['show_subheading'] ) : ?>
			                            <span class="sub-title"><?php print wp_kses_post($settings['subheading_3']); ?></span>
			                        	<?php endif; ?>
			                            <?php if ( $settings['show_heading'] ) : ?>
			                            <h2 class="title"><?php print wp_kses_post($settings['heading_3']); ?></h2>
			                            <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row pricing-box-wrap justify-content-center">
                                <?php
				                    foreach ( $settings['tabs3'] as $item ) : 
								?>
			                    <div class="col-lg-4 col-md-6 col-sm-9">
			                        <div class="pricing-box mb-30">
			                            <div class="pricing-head">
			                                <h6><?php print wp_kses_post($item['title_pricing_3']); ?></h6>
			                                <div class="pricing-icon services-icon">
			                                    <i class="<?php print wp_kses_post($item['icon_3']); ?>"></i>
			                                </div>
			                            </div>
			                            <div class="pricing-list mb-30">
			                                <h5><?php print wp_kses_post($item['subtitle_pricing_3']); ?></h5>
			                                <ul>
			                                    <?php print wp_kses_post($item['content_3']); ?>
			                                </ul>
			                            </div>
			                            <div class="price mb-20">
			                                <h2><?php print wp_kses_post($item['price_3']); ?><span><?php print wp_kses_post($item['period_3']); ?></span></h2>
			                            </div>
			                            <div class="pricing-btn">
			                                <a href="<?php print wp_kses_post($item['link_button_3']); ?>" class="btn"><?php print wp_kses_post($item['button_3']); ?></a>
			                            </div>
			                        </div>
			                    </div>
			                	<?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- pricing-area-end -->
	<?php
	}

}